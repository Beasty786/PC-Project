mpirun -np 8 ./par

./seq

./sim
